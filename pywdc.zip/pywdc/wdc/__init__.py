#!/usr/bin/python
from wdc.dc import *